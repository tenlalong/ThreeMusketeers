package lab2;

import java.util.*;

import lab2.Exceptions.InvalidMoveException;

public class RandomAgent extends Agent {

    public RandomAgent(Board board) {
        super(board);
    }

    /**
     * Gets a valid random move the RandomAgent can do.
     * @return a valid Move that the RandomAgent can perform on the Board
     */
    @Override
public Move getMove() { // TODO

        List<Cell> pCells = board.getPossibleCells();
        Coordinate cord = null;
        List coord = new ArrayList<>();
        List coord1 = new ArrayList<>();
        Cell newCellFrom = null;
        Cell newCellTo = null;
        
        Scanner myObj = new Scanner(System.in);
        
        //for possibleCells
        for(int i = 0; i < pCells.size(); i++) {
            
            int pCellR = pCells.get(i).getCoordinate().row;
            int pCellC = pCells.get(i).getCoordinate().col;
            
            
            char c = Utils.convertIntToLetter(pCellC + 1);
            int r = pCellR + 1;
            
            String newCol = Character.toString(c);
            String newRow = String.valueOf(r);
            String comb = newCol + newRow;
            
            coord.add(comb);
            
        }
        
        System.out.println("Making a move...");
        Random random = new Random();
        String randomString = (String) coord.get(random.nextInt(coord.size()));
        
        if(coord.contains(randomString)) {
            try {
                cord = new Coordinate(Utils.parseUserMove(randomString).row,Utils.parseUserMove(randomString).col);
            } catch (InvalidMoveException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
            newCellFrom = new Cell(cord);
        }
        System.out.printf("[%s]", board.getTurn().getType());
        System.out.print("Moving piece ");
        System.out.print(randomString);
        List<Cell> dCells = board.getPossibleDestinations(newCellFrom);
        
        for(int j = 0; j < dCells.size(); j++) {
            int dCellR = dCells.get(j).getCoordinate().row;
            int dCellC = dCells.get(j).getCoordinate().col;
            
            
            char c = Utils.convertIntToLetter(dCellC + 1);
            int r = dCellR + 1;
            
            String newDC = Character.toString(c);
            String newDR = String.valueOf(r);
            String combD = newDC + newDR;
            
            coord1.add(combD);
        }
        randomString = (String) coord1.get(random.nextInt(coord1.size()));
        
        if(coord1.contains(randomString)) {
        
            try {
                cord = new Coordinate(Utils.parseUserMove(randomString).row,Utils.parseUserMove(randomString).col);
            } catch (InvalidMoveException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
            newCellTo = new Cell(cord);
        }
        
        System.out.print(" to ");
        System.out.print(randomString);
        
        Move botMove = new Move(newCellFrom,newCellTo);
        return botMove;
    }
}

