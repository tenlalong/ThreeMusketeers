package lab2;

import java.util.*;

import lab2.Exceptions.InvalidMoveException;

public class HumanAgent extends Agent {

    public HumanAgent(Board board) {
        super(board);
    }

    /**
     * Asks the human for a move with from and to coordinates and makes sure its valid.
     * Create a Move object with the chosen fromCell and toCell
     * @return the valid human inputted Move
     */
    @Override
    public Move getMove() { // TODO
    	
    	Scanner myObj = new Scanner(System.in);
    	
    	System.out.printf("[%s] Enter a piece in the %s list: ", board.getTurn().getType(), getCoordinates().toString());
    	String input1 = myObj.next().toUpperCase();
    	while(input1.length() != 2 && !getCoordinates().toString().contains(input1)) {
    		System.out.println("Invalid Coordinate");
    		System.out.printf("[%s] Enter a piece in the %s list: ", board.getTurn().getType(), getCoordinates().toString());
    		input1 = myObj.next().toUpperCase();
    	}
    	
    	System.out.printf("[%s] Enter a destination in the %s list: ", board.getTurn().getType(), getDestination(input1));
    	String input2 = myObj.next().toUpperCase();
    	while(input2.length() != 2 && !getDestination(input1).toString().contains(input2)) {
    		System.out.println("Invalid Coordinate");
    		System.out.printf("[%s] Enter a destination in the %s list: ", board.getTurn().getType(), getDestination(input1));
        	input2 = myObj.next().toUpperCase();
    	}
    	
    	Cell currentCell = null;
    	Cell destinationCell = null;
    	
    	try {
			currentCell = new Cell (new Coordinate(Utils.parseUserMove(input1).row, Utils.parseUserMove(input1).col));
		} catch (InvalidMoveException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	try {
			destinationCell = new Cell (new Coordinate(Utils.parseUserMove(input2).row, Utils.parseUserMove(input2).col));
		} catch (InvalidMoveException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	Move finalMove = new Move(currentCell, destinationCell);
    	
    	return finalMove;
    }
    
    private List<Coordinate> getDestination(String fromCell) {
        List<Coordinate> listCoordinates = new ArrayList<Coordinate>();

        Coordinate coordinate = new Coordinate(0,0);
        try {
        	coordinate = new Coordinate(Utils.parseUserMove(fromCell).row, Utils.parseUserMove(fromCell).col);
        } catch (InvalidMoveException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Cell currentCell = new Cell(coordinate);

        for(Cell cell : board.getPossibleDestinations(currentCell)) {
        	listCoordinates.add(cell.getCoordinate());
        }
        return listCoordinates;
    }
    
    private List<Coordinate> getCoordinates() {
        List<Coordinate> coordinates = new ArrayList<Coordinate>();
        for(Cell cell : board.getPossibleCells()) {
            coordinates.add(cell.getCoordinate());
        }
        return coordinates;
    }
}
